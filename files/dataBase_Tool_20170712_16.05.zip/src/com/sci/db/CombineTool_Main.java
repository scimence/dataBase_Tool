﻿
package com.sci.db;

import java.util.ArrayList;
import java.util.List;


/** 对给定的数据库，进行表合并操作 */
public class CombineTool_Main
{
	public static boolean staticModify = false;							// 特定修改逻辑
	public static boolean NOCOPY = false;								// 特定参数，指定在修改完成后，是否复制database2到->database1
	public static List<String> staticTables = new ArrayList<String>();	// 数据库合并时，待修改主键及相关列的表名信息
	public static List<String> CheckColumns = new ArrayList<String>();	// 待检测重名的 表.列
	
	private static final String info1 = "；参数 1-5：需依次传入  IP、帐号、密码、数据名1、数据库名2（如： 10.80.9.31:3309 test test1234 database1 database2）";
	private static final String info2 = "；参数6-n：可指定需要进行主键偏移修改的表名（不传，默认处理database2中所有的表），待去重名处理的表.列（不传，默认不去重名、对于重名项添加服务器名前缀进行去重）";
	private static final String info3 = "；示例： 10.80.9.31:3309 test test1234 database1 database2 player guild player.name guild.name ";
	private static final String info4 = "合并database2到->database1，对表player guild主键进行偏移，对表player列name、表guild列name 加服务器前缀去重名";
	private static final String info5 = "；参数n+1：额外添加参数 NOCOPY ，若存在此参数，则在修改完成后，不复制database2到->database1";
	
	/** 数据库合并主入口，DataBase2 -> DataBase1 */
	public static void main(String[] args)
	{
		String serverName1 = "10.80.9.31:3309";
		String userName1 = "game";
		String password1 = "game@2015.run";
		String DataBaseName1 = "abc";
		
		String serverName2 = "10.80.9.31:3309";
		String userName2 = "game";
		String password2 = "game@2015.run";
		String DataBaseName2 = "abc2";
		
		// args = new String[]{"10.80.9.31:3309", "game", "game@2015.run", "abc", "abc2", "player", "guild", "guild.name", "player.name", "NOCOPY"};
		// 载入参数
		if (args.length >= 5)
		{
			serverName2 = serverName1 = args[0];
			userName2 = userName1 = args[1];
			password2 = password1 = args[2];
			DataBaseName1 = args[3];
			DataBaseName2 = args[4];
			
			if (args.length > 5)
			{
				
				for (int i = 5; i < args.length; i++)
				{
					if (args[i].equals("NOCOPY"))
						NOCOPY = true;				// 含有该参数，则不执行复制操作
					else
					{
						if (args[i].contains("."))	// player.id识别为待去重的列
						{
							if (!CheckColumns.contains(args[i])) CheckColumns.add(args[i]);
						}
						else
						{
							if (!staticTables.contains(args[i])) staticTables.add(args[i]);
						}
					}
				}
				
				if (staticTables.size() > 0) staticModify = true;
			}
		}
		else
		{	// 输出提示信息
			System.out.println(info1);
			System.out.println(info2);
			System.out.println(info3);
			System.out.println(info4);
			System.out.println(info5);
		}
		
		if (args.length >= 5)
		{
			Log.println("============================================");
			
			// 创建两个待操作的数据库对象
			DataBase db1 = new DataBase(serverName1, userName1, password1, DataBaseName1);
			DataBase db2 = new DataBase(serverName2, userName2, password2, DataBaseName2);
			
			if (db1.isConnected && db2.isConnected)	// 数据库连接成功，则执行合并
			{
				// 执行数据库信息合并
				Combine(db1, db2);
				
				// 关闭连接
				db1.finalize();
				db2.finalize();
			}
		}
	}
	
	/** 执行数据库信息合并, 合并数据库db2 -> 到db1 */
	public static void Combine(DataBase db1, DataBase db2)
	{
		List<String> bothHaveTables = Tools.getBothDataBase_HaveTables(db1, db2);	// 获取两个数据库里均含有的表名信息
		Log.println("数据库" + db1.Name + " 和 " + db2.Name + "中，含有表：\r\n" + Tools.ListToSingleStr(bothHaveTables));
		
		List<DataTable> db2Tables = db2.getTableList(bothHaveTables);				// 获取数据库2中对应的表
		List<String> noneEmptyTables = Tools.getNoneEmptyTableNames(db2Tables);		// 获取所有非空表的表名信息
		
		Log.println("--------------------------------------------");
		Log.println("1: 数据库" + db1.Name + " 和 " + db2.Name + "，表类型对比开始...");
		tableTypeCompre(db1.getTableList(noneEmptyTables), db2.getTableList(noneEmptyTables));		// 对比表类型
		Log.println("   \r\n" + tableTypeCompre_result);
		Log.println("   表类型对比完成！");
		
		if (staticModify) noneEmptyTables = staticTables;		// 执行默认修改
		// 修改表中相关的id偏移
		Log.println("--------------------------------------------");
		Log.println("2: " + db2.Name + "，数据表主键偏移，修改开始...");
		ModifyTables(noneEmptyTables, db1, db2);					// 执行表中的第一列id信息修改
		Log.println("   主键偏移修改完成！");
		
		// 修改重名
		if (CheckColumns.size() > 0)
		{
			Log.println("--------------------------------------------");
			Log.println("3: " + db2.Name + "，指定表指定列，重名修改开始...");
			
			// Rename(SamTypeTables, tablesMap1, tablesMap2, serverId);
			RenameTable(db1, db2, CheckColumns);
			Log.println("   列重名修改完成！");
		}
		
		// 从服数据拷进主服数据表中
		if (!NOCOPY)
		{
			Log.println("--------------------------------------------");
			Log.println("4: " + "从服数据库" + db2.Name + "拷贝到 -> 主服数据库" + db1.Name + "开始...");
			TransTableTo(noneEmptyTables, db1, db2);
			Log.println("   表数据复制完成！");
		}
	}
	
	// ------------------
	
	/** 复制table表中的数据，到指定数据库的表中，要求数据库与当前表在同一个服务器上 */
	public static void TransTableTo(DataBase db1, DataBase db2, String tableName)
	{
		// String SQL = "INSERT INTO mainTable  SELECT * FROM secondaryTable"; // 复制当前表中的数据到指定的表中
		String SQL = "INSERT INTO " + db1.Name + "." + tableName + "  SELECT * FROM " + db2.Name + "." + tableName;
		db1.executeUpdate(SQL);
	}
	
	/** 复制数据库db2中的表到db1中，要求数据库与当前表在同一个服务器上 */
	public static void TransTableTo(List<String> TableNames, DataBase db1, DataBase db2)
	{
		for (String tableName : TableNames)
		{
			Log.println("   表复制 " + db2.Name + "." + tableName + " -> " + db1.Name + "." + tableName);
			db2.showExecuteLog = true;
			TransTableTo(db1, db2, tableName);
			db2.showExecuteLog = false;
		}
	}
	
	// ------------------
	
	/** 临时记录tableTypeCompre()函数的执行结果 */
	public static String tableTypeCompre_result = "";
	
	/** 对List中所有的表进行对比，判断列类型是否均相同 */
	public static boolean tableTypeCompre(List<DataTable> tablelList1, List<DataTable> tablelList2)
	{
		boolean result = true;
		tableTypeCompre_result = "";
		
		if (tablelList1.size() != tablelList2.size())
		{
			tableTypeCompre_result = tablelList1.toString() + "和" + tablelList2.toString() + "含有表数目不同！";
			result = false;
		}
		else
		{
			for (int i = 0; i < tablelList1.size(); i++)			// 遍历数据库2中的所有非空共有表，修改其中第一列数据
			{
				DataTable table1 = tablelList1.get(i);				// 获取数据1中表名对应的表
				DataTable table2 = tablelList2.get(i);				// 获取数据2中表名对应的表
				
				if (!table1.ColumnEqual(table2)) result = false;	// 表列类型对比
				tableTypeCompre_result += table1.ColumnEqual_result + "，" + table1.Name() + "和" + table2.Name() + "\r\n";	// 记录处理结果
			}
			tableTypeCompre_result = tableTypeCompre_result.trim();
		}
		return result;
	}
	
	// ------------------
	
	/** 表的主键列或第一列信息修改 */
	public static void ModifyTables(List<String> TableNames, DataBase db1, DataBase db2)
	{
		for (String name : TableNames)	// 遍历所有需要修改的表
		{
			DataTable table1 = db1.getTable(name);	// 获取数据库1中表名对应的表
			DataTable table2 = db2.getTable(name);	// 获取数据库2中指定名称的表
			
			String FirstType = (table2.ColumnType.size() > 0 ? table2.ColumnType.get(0).toString() : "");
			if (FirstType.equals("INT") || FirstType.equals("BIGINT") || FirstType.equals("SMALLINT") || FirstType.equals("TINYINT"))		// 若第一列是整型数据，则执行id偏移修改
			{
				long MaxValue1 = Long.parseLong(table1.getPrimaryMax());	// 获取表1的最大id值
				long MaxValue2 = Long.parseLong(table2.getPrimaryMax());	// 获取表2的最大id值
				long offsetValue = MaxValue1 + MaxValue2 + 100;				// 计算id偏移值
				
				Log.println("MAX(" + table1.Name() + ")：" + MaxValue1 + " + " + "MAX(" + table2.Name() + ")：" + MaxValue2 + " + 100 -> 偏移量：" + offsetValue);
				Log.println_OnlyFile("offset", table2.Name() + "表，\t-> 偏移量：" + offsetValue);
				ModifyDB2(TableNames, db2, name, offsetValue);				// 在数据库2中执行id偏移修改
			}
		}
	}
	
	/** 修改数据库2中和表名tabableName相关的所有列的数据信息，偏移量offsetValue */
	public static void ModifyDB2(List<String> tableNames, DataBase db2, String tabableName, long offsetValue)
	{
		String Codition = "";
		for (DataTable table : db2.getTableList())			// 需遍历数据库中所有的表
		{
			if (table.Name.equals(tabableName))				// 修改当前表的第一列
			{
				String primary = table.getPrimary();		// 获取主键名称
				if (staticModify) Codition = "WHERE " + primary + ">0";
				
				if (!primary.equals("")) OffsetColumnData(table, primary, offsetValue, Codition);
			}
			else if (table.ContainsTable(tabableName))		// 修改相关表的对应列
			{
				if (!staticModify) 	// 特定修改逻辑， 需要table也在指定的表中进行操作
				{
					OffsetColumnData(table, tabableName, offsetValue, "");
				}
				else if (tableNames.contains(table.Name))
				{
					Codition = "WHERE " + tabableName + ">0";
					OffsetColumnData(table, tabableName, offsetValue, Codition);
				}
			}
		}
	}
	
	/** 修改表指定列所有id信息，偏移offset */
	public static void OffsetColumnData(DataTable table, String columnName, long offset, String Condition)
	{
		if (Condition == null) Condition = "";
		// String SQL = "UPDATE hq_cs.guild SET id=id+1000";
		String SQL = "UPDATE " + table.dataBase.Name + "." + table.Name + " SET " + columnName + "=" + columnName + "+" + offset + " " + Condition;	// 更新表中指定列的id信息
		
		table.dataBase.showExecuteLog = true;
		table.dataBase.executeUpdate(SQL);
		table.dataBase.showExecuteLog = false;
	}
	
	/** 修改表指定列所有id信息，偏移offset */
	public static void OffsetColumnData(DataTable table, int columnIndex, long offset, String Condition)
	{
		if (table.ColumnName == null || columnIndex < 0 || columnIndex >= table.ColumnName.size()) return;
		
		String columnName = table.ColumnName.get(columnIndex).toString();
		OffsetColumnData(table, columnName, offset, Condition);
	}
	
	// ------------------
	
	// /** 重命名同名的数据字段 */
	// public static void Rename(List<String> SamTypeTables, Map<String, DataTable> tablesMap1, Map<String, DataTable> tablesMap2, String serverId)
	// {
	// for (String tableName : SamTypeTables)
	// {
	// Log.println("step_3: 修改表" + tableName);
	//
	// DataTable table1 = tablesMap1.get(tableName); // 获取对应的表
	// ResultData result1 = table1.get_Id_Name(); // 获取表1的id和name信息
	//
	// List id1 = result1.GetColumn(0); // 获取id信息
	// List name1 = result1.GetColumn(1); // 获取name信息
	//
	// DataTable table2 = tablesMap2.get(tableName); // 获取对应的表
	// ResultData result2 = table2.get_Id_Name();
	//
	// List id2 = result2.GetColumn(0); // 获取id信息
	// List name2 = result2.GetColumn(1); // 获取name信息
	//
	// for (int i = 0; i < name2.size(); i++) // 遍历从数据库表中所有name信息
	// {
	// String name = name2.get(i).toString();
	// String id = id2.get(i).toString();
	//
	// if (name1.contains(name)) // 修改表table2中与table1重名的name为服务器名_name
	// {
	// table2.RenameData(id, name, serverId);
	// Log.outPutPlayerId(tableName, id); // 输出玩家id信息
	// }
	// }
	// }
	// }
	
	/** 获取区服id */
	public static String getServerId(DataBase db)
	{
		String id = db.Name;
		
		try
		{
			DataTable table = db.getTable("player");
			String sql = "SELECT `id` FROM " + db.Name + ".player LIMIT 1";
			String firstUserId = db.executeQuery(sql).getFirstData().toString();
			
			if (firstUserId.contains("_"))	// 2985952_003_0 解析区服id 003
			{
				String[] A = firstUserId.split("_");
				if (A != null || A.length >= 2) id = Long.parseLong(A[1]) + "";
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return id;
	}
	
	/** 重命名数据库db2->表tableName->列columnName 与数据库db1，存在重名的所有字段 */
	public static void RenameTable(DataBase db1, DataBase db2, List<String> tableName_columnName)
	{
		for (String iteam : tableName_columnName)
		{
			if (iteam.contains("."))
			{
				int index = iteam.indexOf(".");
				String tableName = iteam.substring(0, index);
				String columnName = iteam.substring(index + 1);
				
				RenameTable(db1, db2, tableName, columnName);
			}
		}
	}
	
	/** 重命名数据库db2->表tableName->列columnName 与数据库db1，存在重名的所有字段 */
	public static void RenameTable(DataBase db1, DataBase db2, String tableName, String columnName)
	{
		DataTable table1 = db1.getTable(tableName);
		DataTable table2 = db2.getTable(tableName);
		
		String prefix = "";
		if (staticModify) prefix = getServerId(db2);
		RenameTable(table1, table2, columnName, prefix);
	}
	
	/** 重命名table2中columnName列与table1存在重名的所有列的数据 */
	public static void RenameTable(DataTable table1, DataTable table2, String columnName, String prefix)
	{
		Log.println("   查询" + table2.Name() + "中" + columnName + "列，与" + table1.Name() + "的重名信息...");
		ResultData data = getInnerJoin(table1, table2, columnName);					// 查询表2与表1 columnName列重名的所有数据信息
		
		List primaryList = data.GetColumn(0);
		Log.println((primaryList.size() > 0 ? "" : "不") + "存在重名的项");
		
		// if (primaryList.size() > 0) Rename(table2, primaryList, columnName, prefix); // 重命名columnName列的数据
		if (primaryList.size() > 0) RenameNew(table2, primaryList, columnName, prefix);	// 重命名columnName列的数据
	}
	
	/** 获取获取两张表的交集信息，按指定的columnName取交集 */
	public static ResultData getInnerJoin(DataTable table1, DataTable table2, String columnName)
	{
		// 查询存在于表2中的，与表1中name重名的所有记录信息
		// SELECT abc.TableName_new2.id, abc.TableName_new2.name FROM abc.TableName_new2 INNER JOIN abc2.TableName_new2 USING(`name`)
		// String Columns = table2.Name() + ".`" + table2.getPrimary() + "`," + table2.Name() + ".`" + columnName + "`"; // 选取主键和待排重的列名称
		String Columns = table2.Name() + ".`" + table2.getPrimary() + "`";	// 选取主键和待排重的列名称
		String SQL = "SELECT " + Columns + " FROM " + table2.Name() + " INNER JOIN " + table1.Name() + " USING(`" + columnName + "`)";
		
		table2.dataBase.showExecuteLog = true;
		ResultData data = table2.dataBase.executeQuery(SQL);
		table2.dataBase.showExecuteLog = false;
		
		return data;
	}
	
	/** 重命名主键名称对应所有行的columnName列数据，在该列数据添加前缀prefix， */
	public static void RenameNew(DataTable table2, List<String> primaryValue, String columnName, String prefix)
	{
		if (primaryValue.size() < 0) return;
		
		// UPDATE abc.player SET `name`=CONCAT(`name`,'_abc') WHERE id='2986013_001_0'
		String Condition = "";	// 获取主键名对应的条件串
		String primaryName = table2.getPrimary();
		
		if (prefix == null || prefix.equals("")) prefix = table2.dataBase.Name;		// prefix默认为数据库名
		String SQL = "UPDATE " + table2.Name() + " SET `" + columnName + "`=CONCAT('" + prefix + "_',`" + columnName + "`) WHERE " + Condition;
		
		table2.dataBase.showExecuteLog = true;
		int count = 0;
		for (String value : primaryValue)
		{
			Condition = "`" + primaryName + "`='" + value + "'";
			table2.dataBase.executeUpdate(SQL + Condition);	// 执行名称修改
			
			Log.outPutPlayerId(table2.Name, value + "\r\n");			// 输出主键键值信息
			if (++count > 1)
			{
				table2.dataBase.showExecuteLog = false;
				if (count % 500 == 0) Log.print(".");
			}
		}
		if (count > 0) Log.print("\r\n");
		table2.dataBase.showExecuteLog = false;
		Log.println("修改总行数：" + primaryValue.size());
	}
	
	/** 重命名主键名称对应所有行的columnName列数据，在该列数据添加前缀prefix */
	public static void Rename(DataTable table2, List<String> primaryValue, String columnName, String prefix)
	{
		if (primaryValue.size() < 0) return;
		
		// UPDATE abc.player SET `name`=CONCAT(`name`,'_abc') WHERE id='2986013_001_0'
		String Condition = getPrimaryCondition(table2.getPrimary(), primaryValue);	// 获取主键名对应的条件串
		
		if (prefix == null || prefix.equals("")) prefix = table2.dataBase.Name;		// prefix默认为数据库名
		String SQL = "UPDATE " + table2.Name() + " SET `" + columnName + "`=CONCAT('" + prefix + "_',`" + columnName + "`) WHERE " + Condition;
		
		table2.dataBase.showExecuteLog = true;
		table2.dataBase.executeUpdate(SQL);
		table2.dataBase.showExecuteLog = false;
		
		for (String value : primaryValue)
			Log.outPutPlayerId(table2.Name, value + "\r\n");	// 输出主键键值信息
	}
	
	/** 获取主键名对应的条件串 */
	private static String getPrimaryCondition(String primaryColumnName, List<String> primaryValue)
	{
		// `id`='2986016_001_0' OR `id`='2986016_001_0'
		String Condition = "";
		for (String value : primaryValue)
		{
			Condition += " OR `" + primaryColumnName + "`='" + value + "'";
		}
		if (Condition.length() > 0) Condition = Condition.substring(" OR ".length());
		return Condition;
	}
	
}
