
package com.sci.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/** 定义数据库连接操作类，可查询数据库中的表，执行数据库相关SQL语句 */
public class DataBase
{
	/** mySql数据库连接修改测试逻辑 */
	public static void main(String[] args)
	{
		DataBase db = new DataBase();
		List tableList = db.getTableList();
		System.out.println("数据库" + db.Name + "中含有表：\r\n" + Tools.ListToSingleStr(tableList));
		
		// String sql = "UPDATE abc.player SET `name`='test3' WHERE id='2986013_001_0' OR id='2986016_001_0'";
		// int result = db.executeUpdate(sql);
		// System.out.println("执行完成！" + result);
		
	}
	
	// 声明连接数据库对象
	private Connection connection;			// 数据库连接对象
	private Statement statement;			// 声明SQL语句对象
	
	public String serverName = "10.80.9.31:3309";
	public String userName = "game";
	public String password = "game@2015.run";
	public String Name = "abc";
	
	public boolean isConnected = false;		// 记录是否连接成功
	
	/** 获取数据库信息 */
	public String toString()
	{
		String str = "";
		
		str += "数据库: " + Name;
		str += "Ip端口: " + serverName + "\r\n";
		str += "用户名: " + userName + "\r\n";
		str += "密码: " + password;
		
		return str;
	}
	
	/** 使用默认信息创建数据库连接对象 */
	public DataBase()
	{
		InitDataBase();
	}
	
	/** 使用指定信息，创建数据库连接对象 */
	public DataBase(String serverName, String userName, String password, String DataBase)
	{
		this.serverName = serverName;
		this.userName = userName;
		this.password = password;
		this.Name = DataBase;
		
		InitDataBase();
	}
	
	/** 初始化数据连接，获取数据信息 */
	public void InitDataBase()
	{
		try
		{
			// Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
			// con = DriverManager.getConnection("jdbc:mysql://10.80.9.31:3309/cs", "game", "game@2015.run");
			
			Class.forName("com.mysql.jdbc.Driver");								// 加载JDBC驱动
			
			String url = "jdbc:mysql://" + serverName + "/" + Name;
			connection = DriverManager.getConnection(url, userName, password);	// 连接数据库
			
			statement = connection.createStatement();							// 创建操作对象
			
			getTableNames();	// 获取数据库中的表信息
			Log.println("数据库" + Name + "，已连接");
			
			isConnected = true;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			isConnected = false;
		}
	}
	
	/** 关闭数据库连接 */
	protected void finalize()
	{
		try
		{
			connection.close();
			Log.println("数据库" + Name + "，连接已关闭");
			isConnected = false;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public boolean showExecuteLog = false;		// 标识是否输出执行语句信息
	
	/** 执行指定的sql语句，返回成功修改的行数； Executes the given SQL statement, which may be an INSERT, UPDATE, or DELETE statement or an SQL statement that returns nothing,
	 * such as an SQL DDL statement. */
	public int executeUpdate(String sql)
	{
		if (showExecuteLog) Log.print(Log.getTime2() + " - " + "执行语句：" + (sql.length() > 150 ? sql.substring(0, 150) + " **** " : sql) + "，执行中...");
		
		int result = -1;
		try
		{
			result = statement.executeUpdate(sql);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		if (showExecuteLog) Log.print(" 修改行数 " + result + "\r\n");		// 输出显示执行结果
			
		return result;
	}
	
	/** 执行指定的sql语句，返回执行结果 */
	public ResultSet executeQuery_ResultSet(String sql)
	{
		ResultSet result = null;
		try
		{
			result = statement.executeQuery(sql);
			if (showExecuteLog) Log.println("执行语句：" + sql);
		}
		catch (SQLException e)
		{
			if (showExecuteLog) Log.println("执行语句异常：" + sql);
			e.printStackTrace();
			result = null;
		}
		
		return result;
	}
	
	/** 执行指定的sql语句，获取数据库信息 */
	public ResultData executeQuery(String sql)
	{
		ResultSet result = executeQuery_ResultSet(sql);
		return new ResultData(result);
	}
	
	// ---------------------
	
	/** 获取数据库中的所有表名信息 */
	@SuppressWarnings("unchecked")
	public List<String> getTableNames()
	{
		// String getTableNamesSQL = "SELECT table_name FROM information_schema.tables WHERE table_schema='" + Name + "' AND table_type='base table'";
		String getTableNamesSQL = "SELECT `TABLE_NAME` FROM `INFORMATION_SCHEMA`.`TABLES` WHERE `TABLE_SCHEMA` = '" + Name
				+ "' AND `TABLE_TYPE` = 'BASE TABLE'";
		ResultData data = executeQuery(getTableNamesSQL);
		
		return data.GetColumn(0);
	}
	
	/** 获取数据库下指定名称的表信息 */
	public DataTable getTable(String tableName)
	{
		DataTable table = new DataTable(this, tableName);
		return table;
	}
	
	/** 获取数据库下第index位置的表信息 */
	public DataTable getTable(int index)
	{
		List<String> names = getTableNames();
		DataTable table = new DataTable(this, names.get(index).toString());
		return table;
	}
	
	/** 判断当前数据库中是否含有指定名称的表 */
	public boolean ContainsTable(String tableName)
	{
		List<String> names = getTableNames();
		return names.contains(tableName);
	}
	
	/** 获取数据库中所有表，返回map型数据 */
	public Map<String, DataTable> getTableMap()
	{
		Map<String, DataTable> map = new HashMap<String, DataTable>();
		
		List<String> names = getTableNames();
		for (String tabName : names)
		{
			DataTable table = getTable(tabName);
			map.put(tabName, table);
		}
		
		return map;
	}
	
	/** 获取数据库中所有表，返回List型数据 */
	public List<DataTable> getTableList()
	{
		List<DataTable> list = new ArrayList<DataTable>();
		
		List<String> names = getTableNames();
		for (String tabName : names)
		{
			DataTable table = getTable(tabName);
			list.add(table);
		}
		
		return list;
	}
	
	/** 获取存在数据库中，nameList对应的所有表，返回List型数据 */
	public List<DataTable> getTableList(List<String> nameList)
	{
		List<DataTable> list = new ArrayList<DataTable>();
		
		List<String> names = getTableNames();
		for (String tabName : nameList)
		{
			if (names.contains(tabName))	// 若数据库中存在表
			{
				DataTable table = getTable(tabName);
				list.add(table);
			}
			else list.add(null);
		}
		
		return list;
	}
	
}
