
package com.sci.db;

import java.util.List;


/** 定义数据库表 */
public class DataTable
{
	public String Name = "";	// 表名
	public List ColumnName;		// 结果集合的列名称
	public List ColumnType;		// 结果集合的列类型
	public List ColumnSize;		// 获取列最大字节大小信息
	
	public DataBase dataBase;	// 表所属的数据库
	
	/** 获取 `数据库`.`表名` */
	public String Name()
	{
		return "`" + dataBase.Name + "`.`" + Name + "`";
	}
	
	/** 获取表信息 */
	public String toString()
	{
		String str = "";
		
		str += "数据表: " + Name() + ", " + "有" + ColumnName.size() + "列";
		if (ColumnName.size() > 0)
		{
			str += "\r\n";
			str += "依次为：" + Tools.ListToSingleStr(ColumnName) + "\r\n";
			str += "列类型：" + Tools.ListToSingleStr(ColumnType) + "\r\n";
			str += "列大小：" + Tools.ListToSingleStr(ColumnSize) + "\r\n";
			str += "总行数：" + getRowsNum();
		}
		
		return str;
	}
	
	/** 从数据库和指定的表名构建表对象 */
	public DataTable(DataBase dataBase, String tableName)
	{
		Name = tableName;
		this.dataBase = dataBase;
		
		// String SQL = "SELECT * FROM player  LIMIT 1,3"; // 查询表的前3条数据
		String SQL = "SELECT * FROM " + dataBase.Name + "." + Name + " LIMIT 0";	// 查询表的列数据
		ResultData data = dataBase.executeQuery(SQL);
		
		ColumnName = data.ColumnName();	// 获取列名
		ColumnType = data.ColumnType();	// 获取列类型
		ColumnSize = data.ColumnSize();	// 获取列最大字节大小信息
		
		data.destory();	// 清除查询结果对象
		// getRowsNum(); // 获取行数信息
	}
	
	/** 查询当前表的行数 */
	public long getRowsNum()
	{
		// String SQL = "SELECT COUNT(*) FROM cs.ad_result"; //查询表的行数
		String SQL = "SELECT COUNT(*) FROM " + dataBase.Name + "." + Name;
		ResultData data = dataBase.executeQuery(SQL);
		
		String value = data.getFirstData().toString();		 // 获取查询到的行数
		long rowsNum = value.equals("") ? 0 : Long.parseLong(value);
		
		return rowsNum;
	}
	
	/** 判断当前表是否为空 */
	public boolean isEmpty()
	{
		return getRowsNum() == 0;
	}
	
	/** ColumnEqual()函数的执行结果信息 */
	public String ColumnEqual_result = "";
	
	/** 判断当前表与table的列数目、名称、类型、大小是否均相同 */
	public boolean ColumnEqual(DataTable table)
	{
		boolean isEqual = true;
		ColumnEqual_result = "列类型相同";
		
		if (!Tools.ListEqual(ColumnName, table.ColumnName))					// 列名称是否相同
		{
			isEqual = false;
			ColumnEqual_result = "列名称不相同";
		}
		
		if (isEqual && !Tools.ListEqual(ColumnType, table.ColumnType))		// 列类型是否相同
		{
			isEqual = false;
			ColumnEqual_result = "列类型不相同";
		}
		
		if (isEqual && !Tools.ListEqual(ColumnSize, table.ColumnSize))		// 列大小是否相同
		{
			isEqual = false;
			ColumnEqual_result = "列大小不相同";
		}
		
		return isEqual;
	}
	
	/** 判断当前表的列信息中是否含有表名Table的名称字段 */
	public boolean ContainsTable(String tableName)
	{
		return ColumnName.contains(tableName);
	}
	
	/** 获取表的所有主键列名称 */
	@SuppressWarnings("unchecked")
	public List<String> getPrimary_ColumnName()
	{
		// String SQL = "SHOW KEYS FROM `abc`.`TableName_new` WHERE `Key_name`='PRIMARY'";
		String SQL = "SHOW KEYS FROM `" + dataBase.Name + "`.`" + Name + "` WHERE `Key_name`='PRIMARY'";	// 获取表中指定列的最大值
		ResultData data = dataBase.executeQuery(SQL);
		
		return data.GetColumn("Column_name");
	}
	
	/** 获取表的第一个主键列名称，若无则返回第一列名称 */
	public String getPrimary()
	{
		List<String> primary = getPrimary_ColumnName();	// 获取主键名称
		if (primary.size() > 0) return primary.get(0);
		if (ColumnName.size() > 0) return ColumnName.get(0).toString();
		return "";
	}
	
	/** 获取指定列的最大值 */
	public String getMaxValue(int columnIndex)
	{
		if (ColumnName == null || columnIndex < 0 || columnIndex >= ColumnName.size()) return "";
		
		String columnName = ColumnName.get(columnIndex).toString();
		return getMaxValue(columnName);
	}
	
	/** 获取指定列的最大值 */
	public String getMaxValue(String columnName)
	{
		// String SQL = "SELECT MAX(id) FROM cs.player";
		String SQL = "SELECT MAX(" + columnName + ") FROM " + dataBase.Name + "." + Name;	// 获取表中指定列的最大值
		ResultData data = dataBase.executeQuery(SQL);
		
		String maxValue = (data == null ? "" : data.getFirstData().toString());
		return maxValue;
	}
	
	/** 获取主键的最大值 */
	public String getPrimaryMax()
	{
		List<String> primary = getPrimary_ColumnName();	// 获取主键名称
		String maxValue = primary.size() == 0 ? getMaxValue(0) : getMaxValue(primary.get(0));// 获取表第一个主键的最大值或第一列的最大值
		return maxValue;
	}
	
	// -----------------------------------
	
	// /** 获取id和名称列表信息 */
	// public ResultData get_Id_Name()
	// {
	// // String SQL = "SELECT id,NAME FROM hq_cs.player";
	// String SQL = "SELECT id,`name` FROM " + dataBase.Name + "." + Name; // 获取表中指定列的最大值
	// ResultData data = dataBase.executeQuery(SQL);
	//
	// return data;
	// }
	//
	// /** 修改表指定列所有id信息，偏移offset */
	// public void RenameData(String id, String name, String serverId)
	// {
	// // String SQL = "UPDATE cs.player SET `name`=test WHERE id=100"; // 修改指定id对应行的name信息
	// String reName = serverId + "_" + name;
	// String SQL = "UPDATE " + dataBase.Name + "." + Name + " SET `name`='" + reName + "' WHERE id='" + id + "'";
	// dataBase.executeUpdate(SQL);
	// }
	
	// /** 复制当前表中的数据，到指定数据库的表，要求数据库与当前表在同一个服务器上 */
	// public void TransTableTo(String DataBase, String tableName)
	// {
	// // String SQL = "INSERT INTO mainTable  SELECT * FROM secondaryTable"; // 复制当前表中的数据到指定的表中
	// String SQL = "INSERT INTO " + DataBase + "." + tableName + "  SELECT * FROM " + dataBase.Name + "." + Name;
	// dataBase.executeUpdate(SQL);
	// }
	
}
