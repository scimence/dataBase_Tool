﻿
package com.sci.db;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class Log
{
	/** 输出工具运行信息 */
	public static void println(String info)
	{
		info = getTime2() + " - " + info ;
		System.out.println(info);
		outPutPlayerId("dataBaseToolLog_", info + "\r\n");
	}
	
	/** 输出工具运行信息 */
	public static void print(String info)
	{
		System.out.print(info);
		outPutPlayerId("dataBaseToolLog_", info);
	}
	
	// /** 输出工具运行信息 */
	// public static void println(String info, boolean newLine)
	// {
	// info = getTime2() + " - " + info;
	// outPutPlayerId("dataBaseToolLog_", info, newLine);
	// if(newLine) System.out.println(info);
	// else System.out.print(info);
	//
	// }
	
	/** 仅输出工具运行信息到文件 */
	public static void println_OnlyFile(String tableName, String info)
	{
		info = getTime2() + " - " + info;
		outPutPlayerId(tableName + "_", info + "\r\n");
	}
	
	/** 输出玩家id信息, newLine记录是否换行 */
	public static void outPutPlayerId(String tableName, String id)
	{
		FileWriter fw = getFileWriter(tableName);
		try
		{
			// 写入文本，可在id后配置相关道具，方便运营之后操作
			fw.write(id);
			fw.flush();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	// ------------------------------------
	
	/** 获取当前时间 */
	private static String getTime()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dt = new Date();
		String time = sdf.format(dt);
		return time;
	}
	
	/** 获取当前时间 */
	public static String getTime2()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dt = new Date();
		String time = sdf.format(dt);
		return time;
	}
	
	/** 输出玩家id信息 */
	private static Map<String, FileWriter> map = new HashMap<String, FileWriter>();
	
	private static FileWriter getFileWriter(String tableName)
	{
		FileWriter fw = null;
		if (map.containsKey(tableName))
			fw = map.get(tableName);
		else
		{
			File file = new File("res/" + tableName + getTime() + ".txt");
			if (!file.getParentFile().exists())
			{
				file.getParentFile().mkdirs();
			}
			
			try
			{
				if (!file.exists()) file.createNewFile();
				fw = new FileWriter("res/" + tableName + getTime() + ".txt", true);
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}
			
			map.put(tableName, fw);
		}
		return fw;
	}
	
}
