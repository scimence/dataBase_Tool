
package com.sci.db;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/** 获取ResultSet中的数据信息 */
public class ResultData
{
	public ResultSet resultSet;	// 结果集合
	
	/** 获取ResultSet中的数据信息 */
	public ResultData(ResultSet set)
	{
		this.resultSet = set;
	}
	
	/** 清空数据变量 */
	public void destory()
	{
		resultSet = null;
	}
	
	/** 获取结果集合的列名称信息 */
	public List ColumnName()
	{
		return getColomnName(resultSet);
	}
	
	/** 获取结果集合的列类型信息 */
	public List ColumnType()
	{
		return getColumnType(resultSet);
	}
	
	/** 获取结果集合的列类型信息的最大字节大小 */
	public List ColumnSize()
	{
		return getColumnSize(resultSet);
	}
	
	List<Map> rows = null;
	
	/** 获取结果集合的行数据信息 */
	public List<Map> Rows()
	{
		if (rows == null) rows = getRows(resultSet);
		return rows;
	}
	
	/** 获取列数据 */
	public List GetColumn(Object name)
	{
		List ColumnName = ColumnName();
		List<Map> Rows = Rows();
		
		List list = new ArrayList();
		if (ColumnName.contains(name))
		{
			for (Map row : Rows)
			{
				Object obj = row.get(name);
				list.add(obj == null ? "" : obj.toString());
			}
		}
		return list;
	}
	
	/** 获取列数据 */
	public List GetColumn(int index)
	{
		List ColumnName = ColumnName();
		if (index < 0 || index >= ColumnName.size())
			return new ArrayList();
		else
		{
			Object colName = ColumnName.get(index);
			return GetColumn(colName);
		}
	}
	
	/** 获取第一行第一列的数据 */
	public Object getFirstData()
	{
		List column1 = GetColumn(0);					// 获取第0列数据
		if (column1.size() > 0 && column1.get(0) != null)
			return column1.get(0);	// 获取第1行数据
		else return "";
	}
	
	// ---------------------
	// 静态数据转化函数
	
	/** 获取结果集合的列名称信息 */
	public static List getColomnName(ResultSet set)
	{
		List Names = new ArrayList();
		
		try
		{
			ResultSetMetaData tittle = set.getMetaData();	// 获取列头信息
			int num = tittle.getColumnCount();				// 获取列数目
			for (int i = 1; i <= num; i++)
			{
				Names.add(tittle.getColumnName(i).toString());	// 获取列名称信息
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return Names;
	}
	
	/** 获取结果集合的列类型信息 */
	public static List getColumnType(ResultSet set)
	{
		List Names = new ArrayList();
		
		try
		{
			ResultSetMetaData tittle = set.getMetaData();	// 获取列头信息
			int num = tittle.getColumnCount();				// 获取列数目
			for (int i = 1; i <= num; i++)
			{
				Names.add(tittle.getColumnTypeName(i));		// 获取列名称信息
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return Names;
	}
	
	/** 获取结果集合的列类型信息的最大字节大小 */
	public static List getColumnSize(ResultSet set)
	{
		List Names = new ArrayList();
		
		try
		{
			ResultSetMetaData tittle = set.getMetaData();	// 获取列头信息
			int num = tittle.getColumnCount();				// 获取列数目
			for (int i = 1; i <= num; i++)
			{
				Names.add(tittle.getColumnDisplaySize(i));	// 列最大占用字节大小
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return Names;
	}
	
	/** 通用取结果方案,返回list */
	public static List<Map> getRows(ResultSet set)
	{
		List listOfRows = new ArrayList();
		
		try
		{
			ResultSetMetaData tittle = set.getMetaData();	// 获取列头信息
			int num = tittle.getColumnCount();				// 获取列数目
			while (set.next())
			{
				Map mapOfColValues = new HashMap(num);		// 记录每行的列数据
				for (int i = 1; i <= num; i++)
				{
					mapOfColValues.put(tittle.getColumnName(i), set.getObject(i));	// 按列名称记录数据到行map中
				}
				listOfRows.add(mapOfColValues);				// 记录行数据到List
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return listOfRows;
	}
	
	// /** 通用取结果方案,返回JSONArray */
	// public static JSONArray extractJSONArray(ResultSet rs)
	// {
	// JSONArray array = new JSONArray();
	// try
	// {
	// ResultSetMetaData md = rs.getMetaData();
	// int num = md.getColumnCount();
	// while (rs.next())
	// {
	// JSONObject mapOfColValues = new JSONObject();
	// for (int i = 1; i <= num; i++)
	// {
	// mapOfColValues.put(md.getColumnName(i), rs.getObject(i));
	// }
	// array.add(mapOfColValues);
	// }
	// }
	// catch (Exception e)
	// {
	// e.printStackTrace();
	// }
	// return array;
	// }
}
