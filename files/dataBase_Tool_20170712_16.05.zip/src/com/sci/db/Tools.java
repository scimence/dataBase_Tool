
package com.sci.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/** 通用功能函数类 */
public class Tools
{
	/** 转化list为单个字符串 */
	public static String ListToSingleStr(List list)
	{
		String str = "";
		for (Object iteam : list)
			str += "," + iteam;
		if (str.startsWith(",")) str = str.substring(1);
		return str;
	}
	
	/** 获取数据库db1和db2中均含有的表名 */
	public static List<String> getBothDataBase_HaveTables(DataBase db1, DataBase db2)
	{
		List<String> list = new ArrayList<String>();
		for (String tableName : db1.getTableNames())
		{
			if (db2.ContainsTable(tableName)) list.add(tableName);
		}
		return list;
	}
	
	/** 获取tableMap所有表中，主键列的最大值信息 */
	public static Map<String, String> getPrimaryMax(Map<String, DataTable> tableMap)
	{
		Map<String, String> map = new HashMap<String, String>();
		for (String tabName : tableMap.keySet())
		{
			DataTable table = tableMap.get(tabName); 				// 获取指定的表
			List<String> primary = table.getPrimary_ColumnName();	// 获取主键名称
			String maxValue = primary.size() == 0 ? table.getMaxValue(0) : table.getMaxValue(primary.get(0)); 	// 获取表第一个主键的最大值或第一列的最大值
			
			map.put(tabName.toString(), maxValue); 		// 记录各表第一列的最大值信息
		}
		
		return map;
	}
	
	/** 获取数据表列表中所有非空表的表名信息 */
	public static List<String> getNoneEmptyTableNames(List<DataTable> tableList)
	{
		List<String> list = new ArrayList<String>();
		for (DataTable table : tableList)			// 遍历所有表名
		{
			if (table != null && !table.isEmpty())	// 若表存在且非空
			{
				list.add(table.Name);				// 记录非空表
			}
		}
		
		return list;
	}
	
	/** 判断当两个list中的内容是否完全相同 */
	public static boolean ListEqual(List list1, List list2)
	{
		boolean isEqual = true;
		
		if (list1 != null && list2 != null && list1.size() == list2.size())
		{
			for (int i = 0; i < list1.size(); i++)
			{
				// String value1 = list1.get(i).toString();
				// String value2 = list2.get(i).toString();
				// if (!value1.equals(value2)) // 存在数据不相同则不相同
				if (!list1.get(i).equals(list2.get(i)))	// 存在数据不相同则不相同
				{
					isEqual = false;
					break;
				}
			}
		}
		else if (list1 == null && list2 == null)
			;
		else isEqual = false;
		
		return isEqual;
	}
	
}
